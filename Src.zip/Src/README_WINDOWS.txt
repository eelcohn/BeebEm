BeebEm for Microsoft Windows
============================

Compiling
---------

This distribution of BeebEm contains Windows executables but if you want to
compile BeebEm yourself then you will need Microsoft Visual Studio 2008 or
later (the free VS2008 Express will compile BeebEm). The following project
files are included:

  BeebEm.sln     - Solution file
  BeebEm.vcproj  - Project file

You will need to download and install the following SDKs:

- Microsoft DirectX 9.0 SDK

Note: The sources have been updated to build with the latest DirectX SDK.

You may also need to install:

- Windows SDK (e.g. Microsoft Windows SDK for Windows 7 and .NET Framework 4)
