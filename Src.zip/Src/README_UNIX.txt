UNIX VERSION OF BEEBEM
----------------------

This version of BeebEm will not compile on UNIX systems.  This may
change at some point but for now if you want to run BeebEm on UNIX
please download a UNIX specific version of BeebEm.
